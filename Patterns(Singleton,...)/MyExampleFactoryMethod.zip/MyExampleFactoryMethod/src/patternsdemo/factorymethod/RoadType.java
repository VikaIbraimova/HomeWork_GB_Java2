package patternsdemo.factorymethod;

/**
 * Created by vika on 22.06.16.
 */
public enum RoadType {
    CITY,
    OFF_ROAD,
    GAZON
}
