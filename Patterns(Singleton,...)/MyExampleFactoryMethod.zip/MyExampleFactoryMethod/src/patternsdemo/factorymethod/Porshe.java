package patternsdemo.factorymethod;

/**
 * Created by vika on 22.06.16.
 */
/**
 * Данный класс реализует интерфейс Car -
 * подписывается под условия контракта Car, тоесть обязан реализовать его методы
 */
public class Porshe implements Car {
    @Override
    public void drive() {
        System.out.println("Drive speed 150 km/h");
    }

    @Override
    public void stop() {
        System.out.println("Stopped at 1 sec");
    }
}
