package patternsdemo.factorymethod;

/**
 * Created by vika on 22.06.16.
 */

/**
 * Данный класс реализует интерфейс Car -
 * подписывается под условия контракта Car, тоесть обязан реализовать его методы
 */
public class Jeep implements Car {

    @Override
    public void drive() {
        System.out.println("Drive speed 50 km/h");
    }

    @Override
    public void stop() {
        System.out.println("Stopped at 5 sec");
    }
}
