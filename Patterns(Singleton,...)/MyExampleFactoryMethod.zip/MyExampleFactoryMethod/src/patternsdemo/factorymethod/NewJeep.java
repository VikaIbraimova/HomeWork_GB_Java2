package patternsdemo.factorymethod;

/**
 * Created by vika on 22.06.16.
 */

/**
 * Данный класс наследуется от класса Jeep
 * NewJeep может переопределять методы+
 * может создавать новые
 */
public class NewJeep extends Jeep {
    public void newFucntion() {
        System.out.println("new function");
    }
}
