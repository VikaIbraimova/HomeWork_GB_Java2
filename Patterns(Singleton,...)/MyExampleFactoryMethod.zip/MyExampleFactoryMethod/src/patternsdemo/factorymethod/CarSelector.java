package patternsdemo.factorymethod;

/**
 * Created by vika on 22.06.16.
 */
public class CarSelector {
    /**
     * Метод getCar является фабричным, потому что
     * клаас CarSelector является фабрикой по созданию автомобилей,
     * тоесть в этом классе создаются все типы автомобилей.
     * Метод getCar  как раз и создает нужный автомобиль.
     * @param roadType
     * @return
     */

    public Car getCar(RoadType roadType) {
        Car car = null;
        switch (roadType) {
            case CITY:
                car = new Porshe();
                //car = new BMW();
                break;
            case OFF_ROAD:
                car = new Jeep();
                break;
            case GAZON:
                car = new NewJeep();
                break;
        }
        return car;
    }
}
