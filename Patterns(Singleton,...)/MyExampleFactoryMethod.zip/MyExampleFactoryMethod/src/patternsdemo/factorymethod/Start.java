package patternsdemo.factorymethod;

/**
 * Created by vika on 22.06.16.
 */
public class Start {
    public static void main(String[] args) {
        /**
         * Создаем экземпляр фабрики
         */
        CarSelector carSelector = new CarSelector();

        /**
         * Теперь через фабрику создаем наши автомобили, в зависимости от
         * входящих условий
         */
        /**
         * Самое важное:Теперь ,если нужно поменять автомобиль Porshe,
         * который создавался исходя из входящего условия - CITY,
         * например на авто BMW, то мы просто идем в класс с нашей фабрикой и
         * меняем в одном месте - создание авто Porshe на BMW
         * Только не забудьте или созать новый класс BMW или поменять название Porshe На BMW
         */
        Car car1 = carSelector.getCar(RoadType.CITY);
        car1.drive();
        car1.stop();
    }
}
