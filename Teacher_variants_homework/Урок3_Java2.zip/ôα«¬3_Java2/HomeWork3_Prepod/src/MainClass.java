import java.util.*;

/**
 * Created by vika on 28.05.16.
 */
public class MainClass {
    public static void main(String[] args) {
        /**
         * 1) Создать строку с небольшим текстом(20-30 слов, в котором должны встречать повторяющиеся слова):
         * а) Посчитать сколько раз встречается каждое слово;
         * б) Найти список слов из которых состоит текст(дубликаты не считаем);
         */
        /**
         * Создали строку и с помощью пробелов разбили ее на буквы
         */
        String[] a = new String ("A B C A B D E C B E F A").split(" ");

        //Пункт б
        /**
         * Будем использовать HashSet, т.к нам не нужны дупликаты
         * Тоесть заберм из массива a только уникальные значения
         */
        HashSet<String> hs = new HashSet<String>();
        /**
         * Берем буквы из массива a и кладем их в HashSet
         * Однако не забываем, что HashSet не позволит положить в него
         * повторения
         */
        for (int i = 0; i < a.length; i++) {
            hs.add(a[i]);
        }
        //Вывод на экран
        System.out.println(hs);

        //Пункт a
        /**
         * Будем использовать HashMap: ключ-слово(String), значение-счетчик(Integer)
         */
        HashMap<String,Integer> hm = new HashMap<String,Integer>();
        /**
         * Бежим по циклу, если в HasMap еще нет этого слова,
         * тогда ложим его со значением счетчика 1
         */
        for (int i = 0; i < a.length; i++) {
            if(!hm.containsKey(a[i])) {
                hm.put(a[i],1);
                /**
                 * Иначе кладем в hm слово, а счетчик увеличиваем:
                 * берем индекс слова и прибавляем к нему 1
                 */
            } else hm.put(a[i],hm.get(a[i])+1);
        }

        /**
         * Вывод на экран с помощью итератора
         */
        Iterator<Map.Entry<String,Integer>> iter = hm.entrySet().iterator();
        while (iter.hasNext()){
            System.out.println(iter.next());
        }
        /**
         * Вывод через foreach
         */
        /*Set<Map.Entry<String, Integer>> set = hm.entrySet();
        for (Map.Entry<String, Integer> me : set) {
            System.out.print(me.getKey() + ": ");
            System.out.println(me.getValue());
        }*/

        //------------------------------------------------------------------------------------------------------------

        /**
         * 2) Написать простой класс ТелефонныйСправочник:
         * а) В каждой записи всего три поля: Фамилия, Телефон, email;
         * б) Сделать возможность добавления и удаления записей из справочника(удаление по фамилии);
         * в) Отдельный метод для поиска номера телефона по фамилии
         * (ввели фамилию, получили телефон), и отдельный метод для поиска email'a по фамилии.
         Итого в п. 2 должно быть 3 класса МэинКласс, ТелефонныйСправочник, ТелефоннаяЗапись.
         */

        PhoneBook pb = new PhoneBook();
        pb.add(new PhoneBookEntry("Ivanov","qaz@mail.ru","123"));
        pb.add(new PhoneBookEntry("Petrov","wsx@mail.ru","456"));
        pb.add(new PhoneBookEntry("Sidorov","edc@mail.ru","789"));

        /**
         * Получение телефона по Фамилии
         */
        System.out.println(pb.getTelephoneByFIO("Petrov"));
    }
}