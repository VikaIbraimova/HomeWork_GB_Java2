/**
 * Created by vika on 29.05.16.
 */

/**
 * Телефонная запись
 */
public class PhoneBookEntry {
    String fio;
    String email;
    String telephone;

    public PhoneBookEntry(String fio, String email, String telephone) {
        this.fio = fio;
        this.email = email;
        this.telephone = telephone;
    }

    public String getFio() {
        return fio;
    }

    public void setFio(String fio) {
        this.fio = fio;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }
}

