import java.util.HashMap;

/**
 * Created by vika on 29.05.16.
 */
//Телефонная книга, в которой телефонные записи
public class PhoneBook {
    /**
     * Если будет посик по фамилии
     */
    HashMap<String,PhoneBookEntry> book;

    public PhoneBook() {
        book = new HashMap<>();
    }

    /**
     * Добавление новой телефонной записи
     */
    public void add(PhoneBookEntry pbe) {
        book.put(pbe.getFio(),pbe);
    }

    public String getEmailByFIO(String fio) {
        return book.get(fio).getEmail();
    }
    public String getTelephoneByFIO(String fio) {
        return book.get(fio).getTelephone();
    }


}
