public class PhoneRecord {
    private String lastName;
    private String phoneNumber;
    private String email;

    public PhoneRecord(String lastName, String phoneNumber, String email) {
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    @Override
    public String toString() {
        return lastName + " " + phoneNumber + " " + email;
    }
}