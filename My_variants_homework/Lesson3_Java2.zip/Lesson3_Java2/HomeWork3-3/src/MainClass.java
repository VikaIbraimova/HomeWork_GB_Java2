import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

public class MainClass {
    public static void main(String[] args) {
        // 1) Создать строку с небольшим текстом(20-30 слов, в котором должны встречать повторяющиеся слова):
        String myString = "получили номера телефона метод каждой для записи три всего поиска номера метод для каждой телефона " +
                "записи три номера каждой метод строку с небольшим текстом поиска должно быть для телефона класса";

        List<String> strList = Arrays.asList(myString.split(" ")); //запись строки в лист
        System.out.println("Считаем сколько раз встречается каждое слово");
        int counter = 1;
        for (int i = 0; i < strList.size(); i++) {
            for (int j = i + 1; j < strList.size() - 1; j++) {
                if (strList.get(i).equals(strList.get(j)))
                    counter++;
            }
            System.out.println(strList.get(i) + " - " + counter);
            counter = 1;
        }

        System.out.println("\nСписок слов из которых состоит текст (дубликаты не считаем):");
        HashSet<String> set = new HashSet<String>();
        set.addAll(strList);
        for (String s : set)
            System.out.println(s);

        System.out.println("\nТелефонный справочник:\n----------------------");
        PhoneBook myPhoneBook = new PhoneBook();
        myPhoneBook.add("Ivanov", "123-12-32", "ivanov@gmail.com");
        myPhoneBook.add("Petrov", "223-12-32", "petrov@gmail.com");
        myPhoneBook.add("Sidorov", "323-12-32", "sidorov@gmail.com");
        myPhoneBook.add("Beldiev", "423-12-32", "beldiev@gmail.com");
        myPhoneBook.add("Pupkin", "523-12-32", "pupkin@gmail.com");

        myPhoneBook.getPhone("Pupkin");
        myPhoneBook.getEmail("Beldiev");
        myPhoneBook.remove("Ivanov");
        System.out.println();
        myPhoneBook.printAllRecord();
    }
}

