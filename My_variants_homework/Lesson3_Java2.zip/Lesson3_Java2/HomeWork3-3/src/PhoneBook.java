import java.util.ArrayList;

public class PhoneBook {
    private ArrayList<PhoneRecord> phoneBook = new ArrayList<PhoneRecord>();

    public void add(String lastName, String phoneNumber, String email) {
        PhoneRecord record = new PhoneRecord(lastName, phoneNumber, email);
        phoneBook.add(record);
    }

    public void printAllRecord() {
        for (PhoneRecord iter : phoneBook) {
            System.out.println(iter.getLastName() + " " + iter.getPhoneNumber() + " " + iter.getEmail());
        }
    }

    public void remove(String lastName) {
        for (int i = 0; i < phoneBook.size(); i++) {
            if ((phoneBook.get(i).getLastName()).equals(lastName)) {
                System.out.println("Удалена запись - " + phoneBook.get(i).toString());
                phoneBook.remove(i);
            }
        }
    }

    public void getPhone(String lastName) {
        for (int i = 0; i < phoneBook.size(); i++) {
            if (phoneBook.get(i).getLastName().equals(lastName))
                System.out.println(phoneBook.get(i).getLastName() + " " + phoneBook.get(i).getPhoneNumber());
        }
    }

    public void getEmail(String lastName) {
        for (int i = 0; i < phoneBook.size(); i++) {
            if (phoneBook.get(i).getLastName().equals(lastName))
                System.out.println(phoneBook.get(i).getLastName() + " " + phoneBook.get(i).getEmail());
        }
    }
}