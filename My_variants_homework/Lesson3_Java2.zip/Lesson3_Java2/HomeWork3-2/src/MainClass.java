import java.util.ArrayList;

/**
 * Created by vika on 27.05.16.
 */
public class MainClass {
    public static void main(String[] args) {

       /* ArrayList<TelephoneDirectory> people = new ArrayList<TelephoneDirectory>();
        people.add(new TelephoneDirectory("Petrov"));
        people.add(new TelephoneDirectory("Sidorov"));
        people.add(new TelephoneDirectory("Ivanov"));

        //System.out.println(people);

        String strFind = "Sidorov";
        for (TelephoneDirectory p : people) {
            System.out.println(p.getName());
            if (p.getName().equals(strFind)) {
                System.out.println("Есть");
            }
        }*/

        //Создание телефонного справочника
        ArrayList<TelephoneDirectory> people = new ArrayList<TelephoneDirectory>();

        //Заполнение телефонного справочника
        people.add(new TelephoneDirectory("Petrov","123","qaz@mail.ru"));
        people.add(new TelephoneDirectory("Sidorov","456","wsx@mail.ru"));
        people.add(new TelephoneDirectory("Ivanov","789","edc@mail.ru"));

        //Вывод на экран
        System.out.println("Вывод всего списка");
        System.out.println(people);

        /**
         * Удаление из списка сотрудника по фамилии
         */
        String strFind = "Sidorov";
        int count = 0;
        for (TelephoneDirectory p : people) {

            System.out.println(p.getName());
            if (p.getName().equals(strFind)) {
                count = count+1;
                System.out.println("Есть");
                people.remove(count);

            }
        }
        System.out.println("Вывод списка после удаления сотрудника");
        System.out.println(people);

        /**
         * Поиск номера телефона по фамилии
         */
        String strFind2 = "Petrov";
        for (TelephoneDirectory p : people) {

            //System.out.println(p.getName());
            //System.out.println(p.getTelephone());
            if (p.getName().equals(strFind2)) {
                //System.out.println("Есть");
                System.out.println("Телефон сотрудника: " + strFind2 + ": " + p.getTelephone());
            }
        }

        /**
         * Поиск email по фамилии
         */
        String strFind3 = "Ivanov";
        for (TelephoneDirectory p : people) {

            //System.out.println(p.getName());
            //System.out.println(p.getTelephone());
            if (p.getName().equals(strFind3)) {
                //System.out.println("Есть");
                System.out.println("Email сотрудника: " + strFind3 + ": " + p.getEmail());
            }
        }
    }
}
