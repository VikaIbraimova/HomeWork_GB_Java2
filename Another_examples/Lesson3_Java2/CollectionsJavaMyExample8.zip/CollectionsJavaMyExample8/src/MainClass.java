import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * Created by vika on 19.06.16.
 */
public class MainClass {
    public static void main(String[] args) {
        List<String> myList1 = new ArrayList<>();
        myList1.add("Корова"); //0
        myList1.add("Лошадь"); //1
        myList1.add("Кенгуру"); //2
        myList1.add("Жираф"); //3
        myList1.add("Тигр"); //4
        myList1.add("Коза"); //5
        myList1.add("Петух"); //6
        myList1.add("Кошка"); //7
        myList1.add("Крокодил"); //8

        /**
         * Обход коллекции с помощью итератора+вывод на экран
         */
        String res = "";
        Iterator iter = myList1.iterator();
        for (int i = 0; iter.hasNext(); i++) {
            System.out.println(iter.next().toString());
        }
        /**
         * Обход коллекции с помощью цикла for+вывод на экран
         */
        System.out.println("Вывод коллекции с помощью цикла for");
        for (String a:myList1) {
            System.out.println(a);
        }

        /**
         * Пример части списка(начиная скакого то номера и заканчивая каким то)
         */
        /*System.out.println("Вывод части коллекции");
        for(String a : myList1.subList(1, 3)) {
            System.out.println(a);
        }*/
        /**
         * Удалим середину коллекции
         */
        /*System.out.println("Вывод колеекции после удаления середины");
        myList1.subList(2, 5).clear();
        for (String a:myList1) {
            System.out.println(a);
        }*/
        /**
         * Выясняем, начинется ли коллекция(список) с определенных элментов
         * Не доделан
         */
        /*System.out.println("Выясняем, начинется ли коллекция(список) с определенных элментов");
        List<String> prefix = Arrays.asList("К", "prefix", "values");
        if(myList1.size() >= prefix.size() &&
                myList1.subList(0, prefix.size()).equals(prefix)) {
            System.out.println("Начинается");
        }*/

        /*/**
         * Для демонстрации методов создадим второй список
         */
        List<String> myList2 = new ArrayList<>();

        /**
         * Добавим во второй список все элементы из первого кроме последнего
         */
        System.out.println("Добавим во второй список все элементы из первого кроме последнего");
        myList2.addAll(myList1.subList(0, myList1.size()-1));
        for (String a:myList2) {
            System.out.println(a);
        }
    }
}
