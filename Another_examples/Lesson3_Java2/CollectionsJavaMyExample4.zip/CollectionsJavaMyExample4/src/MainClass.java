import java.util.HashSet;
import java.util.Iterator;

/**
 * Created by vika on 13.06.16.
 */
public class MainClass {
    public static void main(String[] args) {
        /**
         * Создаем новое множество HashSet и именем(ссылка,которя указывает на адрес в куче, где лижит наше множество)
         */
        HashSet<String> myHashSet = new HashSet<>();
        /**
         * Добавление элемнто в множество
         */
        myHashSet.add("Россия");
        myHashSet.add("Турция");
        myHashSet.add("Испания");
        myHashSet.add("Греция");

        /**
         * Показывет размер множества
         */
        System.out.println("Размер myHashSet: " + myHashSet.size());

        /**
         * Вывод на экран с помощью итератора
         */
        System.out.println("Обход множества myHashSet");
        Iterator<String> itr = myHashSet.iterator();
        while (itr.hasNext()) {
            System.out.println(itr.next().toString());
        }
        /**
         * Возвращает true,если набор не содержит ни одного значения
         */
        System.out.println("Проверяем пустое ли множество");
        System.out.println(myHashSet.isEmpty());
        /**
         * Вернет true, если множество содержит элемент, который мы ищем
         */
        System.out.println("Ищем в нашем множестве myHashSet элемент");
        System.out.println(myHashSet.contains("Испания"));

        /**
         * Добавление одного множества в другое.Для этого:
         * 1)Создаем второе множество
         * 2)Заполняем его элментами
         * 3)Для добавления множества myHashSet2 в множество myHashSet
         * вызываем метод addAll
         * 4)С помощью итератора выводим содержимое множества на экран
         */
        HashSet<String> myHashSet2 = new HashSet<>();
        myHashSet2.add("Швейцария");
        myHashSet2.add("Голландия");
        myHashSet2.add("Беларуссия");

        myHashSet.addAll(myHashSet2);
        Iterator<String> itr2 = myHashSet.iterator();
        while (itr2.hasNext()) {
            System.out.println(itr2.next().toString());
        }

        /**
         * Возвращает массив, содержащий элементы коллекции
         * С myArray можно работать как с массивом - доступны все методы массива
         */
        System.out.println("Конвертируем множество myHashSet в массив myArray");
        String [] myArray = {};
        myArray = myHashSet.toArray(new String[myHashSet.size()]);
        for (int i = 0; i < myArray.length; i++) {
            System.out.println(myArray[i]);
        }


        System.out.println("Удаляем элемент из множества");
        Iterator<String> itr3 = myHashSet.iterator();
        while (itr3.hasNext()) {
            String temp = itr3.next();
            if (temp.equals(new String("Швейцария"))) {
                itr3.remove();
            }
        }
        Iterator<String> itr4 = myHashSet.iterator();
        while (itr4.hasNext()) {
            System.out.println(itr4.next().toString());
        }

        /**
         * Удаляем из множества myHashSet все элементы множества myHashSet2
         * Работает!!!!
         */
        /*System.out.println("До удаления");
        Iterator<String> itr5 = myHashSet.iterator();
        while (itr5.hasNext()) {
            System.out.println(itr5.next().toString());
        }
        boolean resBool = myHashSet.removeAll(myHashSet2);
        System.out.println("После удаления");
        Iterator<String> itr6 = myHashSet.iterator();
        while (itr6.hasNext()) {
            System.out.println(itr6.next().toString());
        }*/
        /**
         * Удаляем из множества HashSet элменты, которые не принадлежат коллекции myHashSet2
         * Работает!!!!
         */
        /*System.out.println("До удаления");
        Iterator<String> itr5 = myHashSet.iterator();
        while (itr5.hasNext()) {
            System.out.println(itr5.next().toString());
        }
        boolean resBool = myHashSet.retainAll(myHashSet2);
        System.out.println("После удаления");
        Iterator<String> itr6 = myHashSet.iterator();
        while (itr6.hasNext()) {
            System.out.println(itr6.next().toString());
        }*/
        /**
         * Удаление всех элментов множества
         * Работает!!!!!
         */
        /*System.out.println("До удаления всех элментов");
        Iterator<String> itr5 = myHashSet.iterator();
        while (itr5.hasNext()) {
            System.out.println(itr5.next().toString());
        }
        myHashSet.clear();
        System.out.println("После удаления");
        Iterator<String> itr6 = myHashSet.iterator();
        while (itr6.hasNext()) {
            System.out.println(itr6.next().toString());
        }*/
        /**
         * Создадим копию множества myHashSet
         */
        System.out.println("До клонирования");
        HashSet myCloneHashSet2 = new HashSet<>();
        Iterator<String> itr5 = myCloneHashSet2.iterator();
        while (itr5.hasNext()) {
            System.out.println(itr5.next().toString());
        }
        //Клон(копия)
        myCloneHashSet2=(HashSet)myHashSet.clone();
        System.out.println("После клонирования");
        Iterator<String> itr6 = myCloneHashSet2.iterator();
        while (itr6.hasNext()) {
            System.out.println(itr6.next().toString());
        }
    }
}
