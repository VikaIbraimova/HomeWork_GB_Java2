import java.util.*;

/**
 * Created by vika on 17.06.16.
 */
public class MainClass {
    public static void main(String[] args) {
        /**
         * Пример 1:
         * Метод выводит случайные числа, а использование коллекции TreeSet
         * гарантирует, что элменты будут отсортированы в порядке возрастания
         */
        Random random = new Random(30);
        SortedSet<Integer> intset = new TreeSet<Integer>();

        for(int i = 0; i < 1000; i++)
            intset.add(random.nextInt(10));
        System.out.println(intset.toString());

        /**
         * Вот, чтобы было, если бы мы не использовали TreeSet,
         * а например ArrayList
         */
        Random random2 = new Random(30);
        ArrayList<Integer> intset2 = new ArrayList<>();

        for(int i = 0; i < 1000; i++)
            intset2.add(random2.nextInt(10));
        System.out.println(intset2.toString());

        /**
         * Со словами пример
         */
        SortedSet<String> stringset = new TreeSet<String>();
        stringset.add("Россия");
        stringset.add("Франция");
        stringset.add("Гондурас");
        stringset.add("Дания"); // любимая страна всех котов

        Iterator itr1 = stringset.iterator();
        while (itr1.hasNext()) {
            String temp = (String) itr1.next();
            System.out.println(temp);
        }
        /**
         * А вот с использованием
         */
        System.out.println("Используем ArrayList");
        Set<String> stringset2 = new HashSet<String>();
        stringset2.add("Россия");
        stringset2.add("Франция");
        stringset2.add("Гондурас");
        stringset2.add("Дания"); // любимая страна всех котов

        Iterator itr2 = stringset2.iterator();
        while (itr2.hasNext()) {
            String temp2 = (String) itr2.next();
            System.out.println(temp2);
        }
        }

    }
