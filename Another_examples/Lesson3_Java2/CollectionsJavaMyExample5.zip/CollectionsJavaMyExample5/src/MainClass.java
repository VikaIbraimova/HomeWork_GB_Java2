import java.util.*;

/**
 * Created by vika on 15.06.16.
 */
public class MainClass {
    public static void main(String[] args) {
        //Создали двусвязный список
        List myList = new LinkedList<String>();
        myList.add("Собака");
        myList.add("Свинья");
        myList.add("Корова");
        Iterator<String> itrMy = myList.iterator();
        while (itrMy.hasNext()) System.out.println(itrMy.next());
        myList.add(2,"Лошадь");
        System.out.println("Добавили еще элемент");
        Iterator<String> itrMy2 = myList.iterator();
        while (itrMy2.hasNext()) System.out.println(itrMy2.next());

        //Обход с использованием итератора
        System.out.println("Обход с использованием итератора");
        ListIterator myLIT1 = myList.listIterator();
        while (myLIT1.hasNext()) {
            System.out.println(myLIT1.next());
        }

        /**
         * Пример вставки в середину LinkedList
         */
        System.out.println("Пример вставки в середину LinkedList");
        //ListIterator<String> myLIT2 = myList.listIterator(2);
        //myLIT2.add("Кошка");
        myList.add(2,"КОШКА");
        ListIterator myLIT2 = myList.listIterator();
        while (myLIT2.hasNext()) {
            System.out.println(myLIT2.next());
        }
    }
}